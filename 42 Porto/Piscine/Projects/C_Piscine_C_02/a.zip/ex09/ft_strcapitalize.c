/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dasantos <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/30 14:08:09 by dasantos          #+#    #+#             */
/*   Updated: 2025/08/30 14:18:57 by dasantos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_alnum(char c)
{
	return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'));
}

char	to_upper(char c)
{
	if (c >= 'a' && c <= 'z')
	{
		return (c - 32);
	}
	else
	{
		return (c);
	}
}

char	to_lower(char c)
{
	if (c >= 'A' && c <= 'Z')
	{
		return (c + 32);
	}
	else
	{
		return (c);
	}
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	new_w;

	i = 0;
	new_w = 0;
	while (str[i] != '\0')
	{
		if(is_alnum(str[i]))
		{
			if(new_w)
			{
				str[i] = to_upper(str[i]);
				new_w = 0;
			}
			else
			{
				str[i] = tp_lower(str[i]);
			}
		}
		else
		{
			new_w = 1;
		}
		i++;
	}
	return (str);
}
/*
#include <stdio.h>

int main(void)
{
    char str2[] = "hello, world!";
    char str3[] = "12345";
    char str4[] = "";

    printf("Result (\"%s\"): %s\n", str2, ft_strcapitalize(str2)); 
    printf("Result (\"%s\"): %s\n", str3, ft_strcapitalize(str3));
    printf("Result (\"%s\"): %s\n", str4, ft_strcapitalize(str4)); 
    return 0;
}
*/
